# Security Policy

## Reporting a bug

Report security bugs via GitHub [issues](https://github.com/usememos/memos/issues).

For more information, please contact [usememos@gmail.com](usememos@gmail.com).

Fork from https://github.com/robfig/cron

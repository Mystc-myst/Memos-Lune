package idp

type IdentityProviderUserInfo struct {
	Identifier  string
	DisplayName string
	Email       string
	AvatarURL   string
}

ALTER TABLE
  resource
ADD
  COLUMN external_link TEXT NOT NULL DEFAULT '';
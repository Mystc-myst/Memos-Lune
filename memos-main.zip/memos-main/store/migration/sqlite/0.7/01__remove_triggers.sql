DROP TRIGGER IF EXISTS `trigger_update_user_modification_time`;

DROP TRIGGER IF EXISTS `trigger_update_memo_modification_time`;

DROP TRIGGER IF EXISTS `trigger_update_shortcut_modification_time`;

DROP TRIGGER IF EXISTS `trigger_update_resource_modification_time`;
DELETE FROM activity;

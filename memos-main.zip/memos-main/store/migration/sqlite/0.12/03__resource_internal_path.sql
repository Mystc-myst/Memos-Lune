ALTER TABLE
  resource
ADD
  COLUMN internal_path TEXT NOT NULL DEFAULT '';
UPDATE
  user_setting
SET
  key = 'memo-visibility'
WHERE
  key = 'memoVisibility';
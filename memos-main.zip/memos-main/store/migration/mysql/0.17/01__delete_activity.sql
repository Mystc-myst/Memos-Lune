DELETE FROM `activity`;

-- Drop deprecated tags column.
ALTER TABLE `memo` DROP COLUMN `tags`;
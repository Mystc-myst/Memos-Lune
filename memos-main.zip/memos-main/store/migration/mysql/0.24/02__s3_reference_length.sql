-- https://github.com/usememos/memos/issues/4322
ALTER TABLE `resource` MODIFY `reference` TEXT NOT NULL DEFAULT ('');

ALTER TABLE `memo` RENAME COLUMN `resource_name` TO `uid`;

ALTER TABLE `resource` RENAME COLUMN `resource_name` TO `uid`;

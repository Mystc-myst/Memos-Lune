-- Drop deprecated tags column.
ALTER TABLE memo DROP COLUMN IF EXISTS tags;
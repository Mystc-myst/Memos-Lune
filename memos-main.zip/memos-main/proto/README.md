# Guide

## Prerequisites

- [buf](https://docs.buf.build/installation)

## Generate

```sh
buf generate
```

## Format

```sh
buf format -w
```

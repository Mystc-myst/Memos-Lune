# Base components in memos

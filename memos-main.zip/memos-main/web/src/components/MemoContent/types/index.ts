export * from "./context";

export interface BaseProps {
  index: string;
  className?: string;
}

const LineBreak = () => {
  return <br />;
};

export default LineBreak;

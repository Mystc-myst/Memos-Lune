export { generateDialog } from "./BaseDialog";

import { MemoRelation_Memo } from "@/types/proto/api/v1/memo_service";

export interface NodeType {
  memo: MemoRelation_Memo;
}

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface LinkType {
  // ...add more additional properties relevant to the link here.
}

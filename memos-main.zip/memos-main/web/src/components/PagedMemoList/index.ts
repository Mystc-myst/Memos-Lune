import PagedMemoList from "./PagedMemoList";

export default PagedMemoList;

import MasonryView from "./MasonryView";

export default MasonryView;
